import numpy as np
import scipy.io as sio
from pmmechnism import pmmechnism
from interval1 import interval1
from attacker_range_uniform_simple import attacker_range_uniform_simple
from Main_pmcalibration import Main_pmcalibration
from mean_PM_sum import mean_PM_sum
from EMF import EMF

np.random.seed(0)

data = sio.loadmat('data_taxi.mat')
user_value = data['A'].T
epsilon = 2

db1 = 1000
m_step = 100
Ht = user_value.shape
user_number = Ht[1]
ep = np.exp(epsilon)
C = (np.exp(epsilon/2) + 1) / (np.exp(epsilon/2) - 1)

# the proportion of attacker
ratio = 0

np.random.shuffle(user_value.T)
group_number = user_number // 4
group1 = user_value[:, :group_number]
group2 = user_value[:, group_number:2*group_number]
group3 = user_value[:, 2*group_number:3*group_number]
group4 = user_value[:, 3*group_number:4*group_number]

group_value = group1

Hj = np.zeros(db1)
for k in range(100):
    user_value_noise_pm1 = pmmechnism(group_value, epsilon, group_number)
    Hj = Hj + interval1(user_value_noise_pm1, db1, C)
hk0 = Hj / 100

O = np.mean(user_value, axis=1)
# 设定不同的攻击者范围，O'-C，这种吗？%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

# [3/4C,C][C/2,C][O,C/2][O,C]
# 第一组
# a1=3/4*C;
# b1=C;
# 第二组
# a1=C/2,C;
# b1=C;
# 第三组[O,C/2]
# a1=O;
# b1=C/2;
# 第四组
a1 = O
b1 = C

attacker_range_uniform_simple
Main_pmcalibration
mean_PM_sum

x_emf, attacker_eva = EMF(data_u_map, db1, t_pm, M0, m_step, number_d2, epsilon, C)
# x_remf=REMF(data_u_map,db1,t_pm,M0,m_step,number_d2,epsilon,ratio);
# %x_remfII=REMFII(data_u_map,db1,t_pm,M0,m_step,number_d2,epsilon,x_remf,C);
#  x_remfII=REMFIII(data_u_map,db1,t_pm,M0,m_step,number_d2,epsilon,x_remf,C,ratio);
#mean_emf=mean_PM(collect_data,d_sw,t,x_emf);

# mean_x_emf=mean_PM1(collect_data,t_pm,number_d2,x_emf,db1,C,data_u_map,group_number,attacker_number);
# mean_x_remf=mean_PM1(collect_data,t_pm,number_d2,x_remf,db1,C,data_u_map,group_number,attacker_number);
#
# mean_x_remfII= mean_PM1(collect_data,t_pm,number_d2,x_remfII,db1,C,data_u_map,group_number,attacker_number);
#
#
#
# digits(4);
# at_pm=[mean_user_value;mean_ostrich;mean_trimming;mean_x_emf;mean
