import numpy as np

def REMFIII(data_u_map, db1, t_pm, M0, m_step, number_d2, epsilon, x, C, ratio):
    # smothing
    # Hj, HB = smothing(number_d2, t_pm, x, C)
    Hj = np.zeros(number_d2 + t_pm)
    HB = np.zeros(number_d2 + t_pm)
    d = number_d2

    # attacker_range_uniform_simple
    at_emf2 = np.zeros(7)

    for loop in range(1):
        # Main_pmcalibration
        # db1 = int(np.floor(np.power(user_number, 1/2)))
        n = data_u_map
        M2 = np.eye(db1)
        t = t_pm
        M4 = M2[:, db1-t:db1]
        M = np.hstack((M0, M4))

        x_record = np.zeros((m_step, d+t))

        x = np.ones(d+t)
        # x[d+pos(th:h1))=0;
        t1 = np.sum(x)
        x[HB+d] = 0
        t2 = np.sum(x)
        x = x * (1/(Hj+d))
        np.sum(x)

        P = np.zeros(d+t)
        for iteration in range(m_step):
            # E
            for i in range(d+t):
                temp0 = 0
                for j in range(db1):
                    mxk = np.sum(M[j,:]*(x))
                    temp0 = temp0 + n[j]*M[j,i]/mxk
                P[i] = x[i]*temp0
            # M
            temp2 = np.zeros(d+t)
            temp2[:d] = P[:d]/np.sum(P[:d])
            x[:d] = temp2[:d]*(1-ratio)
            temp2[d:d+t] = P[d:d+t]/np.sum(P[d:d+t])
            x[d:d+t] = temp2[d:d+t]*ratio

            x_record[iteration,:] = x

            if iteration > 2:
                h = np.sum(np.abs(x_record[iteration-1,:] - x))
                if h < 0.0001*np.exp(epsilon): # 10^-3*exp(epsilon)
                    break

        x_remf2 = x

    return x_remf2