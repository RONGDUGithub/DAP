import numpy as np

def REMF(data_u_map, db1, t_pm, M0, m_step, number_d2, epsilon, ratio, C):
    at_remf = np.zeros(7)
    for loop in range(1):
        n = data_u_map
        M2 = np.eye(db1)
        t = t_pm
        M4 = M2[:, db1-t:db1]
        M = np.hstack((M0, M4))
        d = number_d2
        x_record = np.zeros((m_step, d+t))
        x = np.zeros(d+t) + 1/(d+t)
        P = np.zeros(d+t)

        for iteration in range(1, m_step+1):
            for i in range(1, d+t+1):
                temp0 = 0
                for j in range(1, db1+1):
                    mxk = np.sum(M[j-1, 0:d+t]*x)
                    temp0 += n[j-1]*M[j-1, i-1]/mxk
                P[i-1] = x[i-1]*temp0
            temp2 = np.zeros(d+t)
            temp2[0:d] = P[0:d]/np.sum(P[0:d])
            x[0:d] = temp2[0:d]*(1-ratio)
            temp2[d:d+t] = P[d:d+t]/np.sum(P[d:d+t])
            x[d:d+t] = temp2[d:d+t]*ratio
            x_record[iteration-1, :] = x
            if iteration > 2:
                h = np.abs(x_record[iteration-2, :]-x)
                h = np.sum(h)
                if h < 0.0001*np.exp(epsilon):
                    break
        x_remf = x
        distribution_discrete_EM33
    return x_remf
